const { spawn, exec } = require('child_process');
const path = require('path');

console.log('\n================================');
console.log('      MESSAGERIE PRIVEE');
console.log('================================\n');

// Kill anything on port 3000 first
exec('netstat -aon | findstr ":3000 "', (err, stdout) => {
  if (stdout) {
    const pids = [...new Set(stdout.trim().split('\n').map(l => l.trim().split(/\s+/).pop()).filter(Boolean))];
    pids.forEach(pid => exec(`taskkill /F /PID ${pid}`, () => {}));
  }
});

setTimeout(() => {
  // Start messaging server
  const server = spawn('node', ['server.js'], { cwd: __dirname, stdio: 'inherit' });
  server.on('error', e => console.error('Erreur serveur:', e.message));

  setTimeout(() => {
    console.log('\nCreation du lien public pour ta petite amie...\n');

    const lt = spawn('npx', ['--yes', 'localtunnel', '--port', '3000'], {
      cwd: __dirname,
      shell: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    lt.stdout.on('data', data => {
      const text = data.toString();
      const match = text.match(/your url is:\s*(https?:\/\/\S+)/i);
      if (match) {
        const url = match[1];
        console.log('================================');
        console.log(' LIEN POUR TA PETITE AMIE :');
        console.log('');
        console.log('   ' + url);
        console.log('');
        console.log(' Copie ce lien et envoie-le lui !');
        console.log('================================\n');
        console.log(' Pour se connecter depuis cette page,');
        console.log(' il faudra cliquer "Click to Continue"');
        console.log(' (securite de localtunnel)\n');
      }
    });

    lt.stderr.on('data', data => {
      const text = data.toString();
      if (!text.includes('warn')) process.stdout.write(text);
    });

    lt.on('error', e => {
      console.error('Erreur tunnel:', e.message);
      console.log('\n Alternative : utilise ton IP locale :');
      console.log(' http://192.168.1.175:3000');
      console.log(' (fonctionne sur le meme WiFi)\n');
    });

    lt.on('close', () => {
      console.log('\nTunnel ferme. Relance le script pour un nouveau lien.');
    });

  }, 2000);

}, 500);

process.on('SIGINT', () => {
  console.log('\nArret de la messagerie...');
  process.exit(0);
});
