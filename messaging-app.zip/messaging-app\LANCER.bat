@echo off
title Messagerie Privee
cd /d "%~dp0"
node lancer.js
pause
