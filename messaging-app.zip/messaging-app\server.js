const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const JWT_SECRET = 'messagerie_secret_key_2024';
const PORT = 3000;
const DB_FILE = './db.json';

// Simple JSON database
function loadDB() {
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], messages: [] }));
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// File upload config
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, './public/uploads/'),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|mp4|mov|avi|webm|mkv/i;
    if (allowed.test(path.extname(file.originalname)) || allowed.test(file.mimetype)) return cb(null, true);
    cb(new Error('Fichier non supporté'));
  }
});

app.use(express.json());
app.use(express.static('public'));

// Auth middleware
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Non autorisé' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Token invalide' });
  }
}

// Register
app.post('/api/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) return res.status(400).json({ error: 'Tous les champs sont requis' });
  if (password.length < 6) return res.status(400).json({ error: 'Mot de passe trop court (min 6 caractères)' });
  const db = loadDB();
  if (db.users.find(u => u.email === email.toLowerCase())) {
    return res.status(400).json({ error: 'Cet email est déjà utilisé' });
  }
  const hash = await bcrypt.hash(password, 10);
  const user = { id: Date.now(), email: email.toLowerCase(), password: hash, name, created_at: new Date().toISOString() };
  db.users.push(user);
  saveDB(db);
  const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, name: user.name, email: user.email });
});

// Login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis' });
  const db = loadDB();
  const user = db.users.find(u => u.email === email.toLowerCase());
  if (!user) return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
  const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, name: user.name, email: user.email });
});

// Get all users except me
app.get('/api/users', auth, (req, res) => {
  const db = loadDB();
  const users = db.users.filter(u => u.id !== req.user.id).map(u => ({ id: u.id, name: u.name, email: u.email }));
  res.json(users);
});

// Get messages between two users
app.get('/api/messages/:partnerId', auth, (req, res) => {
  const db = loadDB();
  const partnerId = parseInt(req.params.partnerId);
  const msgs = db.messages.filter(m =>
    (m.sender_id === req.user.id && m.receiver_id === partnerId) ||
    (m.sender_id === partnerId && m.receiver_id === req.user.id)
  ).map(m => {
    const sender = db.users.find(u => u.id === m.sender_id);
    return { ...m, sender_name: sender?.name || 'Inconnu' };
  });
  res.json(msgs);
});

// Send text message
app.post('/api/messages', auth, (req, res) => {
  const { receiver_id, content } = req.body;
  if (!receiver_id || !content?.trim()) return res.status(400).json({ error: 'Destinataire et message requis' });
  const db = loadDB();
  const msg = {
    id: Date.now(),
    sender_id: req.user.id,
    receiver_id: parseInt(receiver_id),
    content: content.trim(),
    file_url: null,
    file_type: null,
    created_at: new Date().toISOString()
  };
  db.messages.push(msg);
  saveDB(db);
  const full = { ...msg, sender_name: req.user.name };
  broadcastMessage(full, req.user.id, parseInt(receiver_id));
  res.json(full);
});

// Upload file
app.post('/api/upload', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Fichier requis' });
  const { receiver_id } = req.body;
  if (!receiver_id) return res.status(400).json({ error: 'Destinataire requis' });
  const db = loadDB();
  const fileUrl = '/uploads/' + req.file.filename;
  const fileType = req.file.mimetype.startsWith('video') ? 'video' : 'image';
  const msg = {
    id: Date.now(),
    sender_id: req.user.id,
    receiver_id: parseInt(receiver_id),
    content: null,
    file_url: fileUrl,
    file_type: fileType,
    created_at: new Date().toISOString()
  };
  db.messages.push(msg);
  saveDB(db);
  const full = { ...msg, sender_name: req.user.name };
  broadcastMessage(full, req.user.id, parseInt(receiver_id));
  res.json(full);
});

// WebSocket
const clients = new Map();
wss.on('connection', (ws, req) => {
  const params = new URLSearchParams(req.url.replace('/?', ''));
  const token = params.get('token');
  try {
    const user = jwt.verify(token, JWT_SECRET);
    clients.set(user.id, ws);
    ws.userId = user.id;
    ws.on('close', () => clients.delete(user.id));
  } catch {
    ws.close();
  }
});

function broadcastMessage(msg, senderId, receiverId) {
  const data = JSON.stringify({ type: 'new_message', message: msg });
  [senderId, receiverId].forEach(id => {
    const client = clients.get(id);
    if (client && client.readyState === WebSocket.OPEN) client.send(data);
  });
}

server.listen(PORT, () => {
  console.log(`\n✅ Messagerie démarrée sur http://localhost:${PORT}`);
  console.log('📱 Ouvre cette URL dans ton navigateur\n');
});
